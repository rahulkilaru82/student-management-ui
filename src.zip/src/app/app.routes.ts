import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'students' },
  {
    path: 'students',
    loadComponent: () =>
      import('./components/students/students-page.component')
        .then(m => m.StudentsPageComponent),
  },
  {
    path: 'courses',
    loadComponent: () =>
      import('./components/courses/courses-page.component')
        .then(m => m.CoursesPageComponent),
  },
   {
    path: 'courses',
    loadComponent: () =>
      import('./components/student-detail/student-detail.component/:id')
        .then(m => m.CoursesPageComponent),
  },
  { path: '**', redirectTo: 'students' }];
